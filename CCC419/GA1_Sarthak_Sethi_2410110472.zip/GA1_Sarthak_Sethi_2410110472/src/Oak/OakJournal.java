/*
* Name: Sarthak Sethi
* Course Code: CSD213
* Roll Number: 2410110472
* Graded Assignment: 1
* */

package Oak;
import Trainer.*;
import Pokemon.*;
import java.util.Scanner;


public class OakJournal {
    private Trainer[] trainers;
    private int trainersCount=0;
    // Default Constructor of Oakjournal Class
    public OakJournal() {

        trainers = new Trainer[10];
        trainersCount=4; // hardcoded 4trainers initially
    }
    // Getter method for trainers array
    public Trainer[] getTrainers(){
        return trainers;
    }
    // Setter method for trainers array
    public void setTrainers(Trainer[] trainers){
        this.trainers = trainers;
    }
    // A method to run the showdown between two trainers and their pokemons
    private void runShowDown(Trainer t1, Trainer t2) {
        System.out.println("Showdown " + t1.getName() + " vs " + t2.getName());
        // If anyone of the trainer is eliminated (ie has lost 3 showdowns the other player ultimately wins
        if(t1.isEliminated()){
            System.out.println("Trainer " + t1.getName() + " has been eliminated");
            System.out.println("Winner is : " + t2.getName());
            return;
        }
        if(t2.isEliminated()){
            System.out.println("Trainer " + t2.getName() + " has been eliminated");
            System.out.println("Winner is : " + t1.getName());
            return;
        }
        int t1Wins=0,t2Wins=0;
        for (int i = 0; i < 6; i++) {
            Pokemon p1 = t1.getPokemon()[i];
            Pokemon p2 = t2.getPokemon()[i];
            System.out.print("Round " + (i + 1) + " " + p1.getName() + " vs " + p2.getName());
            String winner = battle(p1, p2);
            if(winner.equals("draw")){
                System.out.print(": Winner is : It's a draw between " + t1.getName() + " and " + t2.getName());
            }
            else if(winner.equals(p1.getName())){
                t1Wins++;
                System.out.print(" Winner is : " + t1.getName());
            }
            else if(winner.equals(p2.getName())){
                t2Wins++;
                System.out.print(": Winner is : " + t2.getName());
            }
            System.out.println();
        }
        System.out.print("Final Winner is: ");
        /* We determine who teh final winner is based on the total number of wins in a particular showdown */
        if(t1Wins>t2Wins){
            System.out.print(t1.getName());
            t1.recordWin();
            t2.recordLoss();
            t2.setCountLosses(t2.getCountLosses()+1);
        }
        else if(t2Wins>t1Wins){
            System.out.print(t2.getName());
            t2.recordWin();
            t1.recordLoss();
            t1.setCountLosses(t1.getCountLosses()+1);
        }
        else{
            System.out.print("It's a draw between " + t1.getName() + " and " + t2.getName());
        }
        System.out.println();
    }
// A method to simulate a battle between two pokemons
private String battle(Pokemon p1, Pokemon p2) {
        /* Losing conditions if the type of pokemon is different
        * Haven't added any condition for pokemon type Electric( we can add that also) */
    if (p1.getType().equals("Fire") && p2.getType().equals("Grass") ||
            p1.getType().equals("Grass") && p2.getType().equals("Water") ||
            p1.getType().equals("Water") && p2.getType().equals("Fire")) {
        return p1.getName();
    } else if (p2.getType().equals("Fire") && p1.getType().equals("Grass") ||
            p2.getType().equals("Grass") && p1.getType().equals("Water") ||
            p2.getType().equals("Water") && p1.getType().equals("Fire")) {
        return p2.getName();
    } else {
        /* Losing conditions if the type of pokemon is same */
        if (p1.getHealth() > p2.getHealth()) {
            return p1.getName();
        } else if (p2.getHealth() > p1.getHealth()) {
            return p2.getName();
        }
    }
    return "draw";
}
private void addNewTrainer(){
    if (trainersCount >= trainers.length) {
        System.out.println("Cannot add more trainers. Trainer capacity reached");
        return;
    }
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the trainer's name:");
    String name=sc.nextLine();
    // Hardcode a balanced team for the new trainer (Simplification as per assignment instruction)
    Trainer newTrainer = new Trainer(name);
    newTrainer.addPokemon(new Charmander("FireStarter", 50, 20), 0);
    newTrainer.addPokemon(new Squirtle("WaterBoy", 55, 18), 1);
    newTrainer.addPokemon(new Bulbasaur("GrassBlade", 60, 15), 2);
    newTrainer.addPokemon(new Vulpix("FireTail", 48, 18), 3);
    newTrainer.addPokemon(new Psyduck("PsychoDuck", 50, 20), 4);
    newTrainer.addPokemon(new Chikorita("LeafDino", 62, 17), 5);

    trainers[trainersCount++]=newTrainer;
    System.out.println("New Trainer added successfully!`");
}
private void addPokemon() {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the index of the trainer you want to add pokemon to: ");
    int index = sc.nextInt();
    Trainer trainer = trainers[index-1];
    System.out.println("Available Pokémon: Charmander, Vulpix, Squirtle, Psyduck, Greninja, Bulbasaur, Chikorita, Pikachu");
    sc.nextLine();
    System.out.println("Enter the slot at which you want to add the pokemon to ( Slot 1- Slot 6): ");
    int slot = sc.nextInt();
    Pokemon newPokemon;
        System.out.print("Enter the name of Pokémon for slot " + slot + ": ");
        sc.nextLine();
        String pokemon = sc.nextLine().trim();
        if (pokemon.equalsIgnoreCase("Charmander")) {
            newPokemon= new Charmander("Charmander", 55, 20);
        } else if (pokemon.equalsIgnoreCase("Vulpix")) {
            newPokemon= new Vulpix("Vulpix", 48, 18);
        } else if (pokemon.equalsIgnoreCase("Squirtle")) {
            newPokemon= new Squirtle("Squirtle", 58, 17);
        } else if (pokemon.equalsIgnoreCase("Psyduck")) {
            newPokemon= new Psyduck("Psyduck", 50, 15);
        } else if (pokemon.equalsIgnoreCase("Bulbasaur")) {
            newPokemon= new Bulbasaur("Bulbasaur", 60, 16);
        } else if (pokemon.equalsIgnoreCase("Chikorita")) {
            newPokemon= new Chikorita("Chikorita", 62, 17);
        } else if (pokemon.equalsIgnoreCase("Pikachu")) {
            newPokemon= new Pikachu("Pikachu", 55, 22);
        } else {
            // if the input is invalid we will assign bulbasaur to that slot
            newPokemon= new Bulbasaur("Bulbasaur", 60, 15);
        }
        // Add the pokemon to that trainer
        trainer.addPokemon(newPokemon, slot-1);
}
public static void main(String[] args) {
    //Some hardcoded data
    Trainer ash = new Trainer("Ash");
    Trainer misty = new Trainer("Misty");
    Trainer brock = new Trainer("Brock");
    Trainer gary = new Trainer("Gary");

    /*Sarthak's team (deafult)
    newTrainer.addPokemon(new Charmander("FireStarter", 50, 20), 0);
    newTrainer.addPokemon(new Squirtle("WaterBoy", 55, 18), 1);
    newTrainer.addPokemon(new Bulbasaur("GrassBlade", 60, 15), 2);
    newTrainer.addPokemon(new Vulpix("FireTail", 48, 18), 3);
    newTrainer.addPokemon(new Psyduck("PsychoDuck", 50, 20), 4);
    newTrainer.addPokemon(new Chikorita("LeafDino", 62, 17), 5);
*/

    // Ash's team
    ash.addPokemon(new Charmander("Charmander", 50, 20), 0);
    ash.addPokemon(new Bulbasaur("Bulbasaur", 60, 15), 1);
    ash.addPokemon(new Pikachu("Pikachu", 55, 25), 2);
    ash.addPokemon(new Vulpix("Vulpix", 48, 18), 3);
    ash.addPokemon(new Squirtle("Squirtle", 58, 20), 4);
    ash.addPokemon(new Chikorita("Chikorita", 62, 17), 5);

    // Misty's team
    misty.addPokemon(new Squirtle("Squirtle", 55, 18), 0);
    misty.addPokemon(new Chikorita("Chikorita", 60, 17), 1);
    misty.addPokemon(new Psyduck("Psyduck", 50, 20), 2);
    misty.addPokemon(new Bulbasaur("Bulbasaur", 57, 16), 3);
    misty.addPokemon(new Charmander("Charmander", 52, 21), 4);
    misty.addPokemon(new Pikachu("Pikachu", 56, 24), 5);

    // Brock's team
    brock.addPokemon(new Bulbasaur("Bulbasaur", 45, 15), 0);
    brock.addPokemon(new Vulpix("Vulpix", 40, 18), 1);
    brock.addPokemon(new Squirtle("Squirtle", 50, 20), 2);
    brock.addPokemon(new Chikorita("Chikorita", 45, 16), 3);
    brock.addPokemon(new Psyduck("Psyduck", 50, 20), 4);
    brock.addPokemon(new Bulbasaur("Bulbasaur", 50, 15), 5);

    // Gary's team (weak)
    gary.addPokemon(new Charmander("Charmander", 50, 20), 0);
    gary.addPokemon(new Squirtle("Squirtle", 50, 18), 1);
    gary.addPokemon(new Pikachu("Pikachu", 55, 25), 2);
    gary.addPokemon(new Bulbasaur("Bulbasaur", 40, 17), 3);
    gary.addPokemon(new Vulpix("Vulpix", 0, 19), 4);
    gary.addPokemon(new Psyduck("Psyduck", 0, 18), 5);

    OakJournal journal = new OakJournal();
    journal.trainers[0]=ash;
    journal.trainers[1]=misty;
    journal.trainers[2]=brock;
    journal.trainers[3]=gary;

    Scanner sc = new Scanner(System.in);
    int choice=-1;
    do {
        System.out.println("\n------- Pokémon Battle Simulator Menu -------");
        System.out.println("1. List Trainers");
        System.out.println("2. Add New Trainer");
        System.out.println("3. Add Pokémon to a Trainer");
        System.out.println("4. Run a Showdown Battle");
        System.out.println("0. Exit Program");
        System.out.print("Enter your choice: ");
        choice=sc.nextInt();

        switch (choice) {
            case 1:
                for(int i=0;i< journal.trainersCount;i++)
                {
                    System.out.println((i+1)+".  "+journal.trainers[i].getName());
                }
                break;
            case 2:
                journal.addNewTrainer();
                break;
            case 3:
                journal.addPokemon();
                break;
            case 4:
                System.out.println("Enter the index of trainers you want to see a showdown between: ");
                int index1 = sc.nextInt()-1;
                int index2 = sc.nextInt()-1;
                journal.runShowDown(journal.trainers[index1], journal.trainers[index2]);
                break;
            case 0:
                System.out.println("Shutting down simulator");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    } while (choice != 0);
}
}

