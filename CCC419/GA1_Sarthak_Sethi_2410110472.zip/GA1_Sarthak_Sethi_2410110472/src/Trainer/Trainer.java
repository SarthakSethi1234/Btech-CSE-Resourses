package Trainer;
import Pokemon.*;
/* I haven't includes setName or setBadge methods because
I think the user should not get the facility to change that once initialised */
public class Trainer {
    private String name;
    private Pokemon[] pokemons;
    private int BadgeCount;
    private int countLosses;
    // Default Constructor for Trainer Class
    public Trainer() {
        this.name = "Trainer";
        this.BadgeCount=0;
        pokemons=new Pokemon[6];
        this.countLosses=0;
    }
    // Parametrised Constructor for Trainer Class
    public Trainer(String name) {
        this.name = name;
        this.BadgeCount=0;
        pokemons=new Pokemon[6];
        this.countLosses=0;
    }
    // A getter method for the name of the trainer
    public String getName(){
        return name;
    }
    // A getter method for BadgeCount
    public int getBadgeCount(){
        return BadgeCount;
    }
    public void addPokemon(Pokemon pokemon,int slot){
        /* I have given the facility to replace a pokemon if there already exists another pokemon
        in the given slot number */
        if(slot<0 || slot>5){
            System.out.println("Invalid Slot Number");
        }
        else {
            pokemons[slot] = pokemon;
        }
    }
    // Getter method for pokemons array
    public Pokemon[] getPokemon(){
        return pokemons;
    }
    // A method to increase the BadgeCount if the trainer wins
    public void recordWin()
    {
        this.BadgeCount++;
    }
    // A method to decrease the BadgeCount if the trainer loses a showdown
    public void recordLoss(){
        // Ensuring that the BadgeCount just doesn't go below zero ie it becomes negative
        if(this.BadgeCount!=0) {
            this.BadgeCount--;
        }
    }
    // This method return true if the total losses of a trainer is greater than or equal to 3
    public boolean isEliminated(){
        return countLosses>=3;
    }
    // Getter method for countLosses
    public int getCountLosses(){
        return countLosses;
    }
    // Setter method for countLosses
    public void setCountLosses(int countLosses){
        this.countLosses = countLosses;
    }
}