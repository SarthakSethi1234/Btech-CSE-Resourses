package Pokemon;

public abstract class Water extends Pokemon{
    public Water(String name, int health) {
        super(name, health);
    }
    public String getType(){
        return "Water";
    }
}
