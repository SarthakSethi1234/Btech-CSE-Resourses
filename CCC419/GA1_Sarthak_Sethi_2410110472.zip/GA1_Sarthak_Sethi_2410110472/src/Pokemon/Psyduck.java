package Pokemon;

public class Psyduck extends Water{
    private int specialMoveDamage;
    public Psyduck(String name, int health, int specialMoveDamage) {
        super(name, health);
    }
    public int getSpecialMoveDamage() {
        return specialMoveDamage;
    }
    public void setSpecialMoveDamage(int specialMoveDamage) {
        this.specialMoveDamage = specialMoveDamage;
    }
}
