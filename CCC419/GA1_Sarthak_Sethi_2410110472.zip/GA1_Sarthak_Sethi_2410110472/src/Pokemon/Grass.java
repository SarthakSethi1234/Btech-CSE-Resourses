package Pokemon;

public abstract class Grass extends Pokemon {
    public Grass(String name, int health) {
        super(name, health);
    }

    public String getType() {
        return "Grass";
    }
}
