package Pokemon;

public abstract class Electric extends Pokemon {
    public Electric(String name, int health) {
        super(name,health);
    }
    public String getType(){
        return "Electric";
    }
}
