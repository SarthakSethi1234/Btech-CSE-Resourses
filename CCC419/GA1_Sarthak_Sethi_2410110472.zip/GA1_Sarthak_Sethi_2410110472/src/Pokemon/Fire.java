package Pokemon;

public abstract class Fire extends Pokemon{
    public Fire(String name, int health) {
        super(name, health);
    }
    public String getType(){
        return "Fire";
    }
}