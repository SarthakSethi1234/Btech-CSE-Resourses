package Pokemon;

public abstract class Pokemon {
    private String name;
    private int health;
    public abstract String getType();
    Pokemon(String name, int health) {
        this.name = name;
        this.health = health;
    }
    public String getName() {
        return name;
    }
    public int getHealth() {
        return health;
    }
}
